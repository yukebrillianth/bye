$('.count').countdowntimer({
    dateAndTime : "2020/09/14",
  });  